create function mt_jsonb_duplicate(jsonb, text[], jsonb) returns jsonb
    language plpgsql
as
$$
DECLARE
    retval ALIAS FOR $1;
    location ALIAS FOR $2;
    targets ALIAS FOR $3;
    tmp_value jsonb;
    target_path text[];
    target text;
BEGIN
    FOR target IN SELECT jsonb_array_elements_text(targets)
    LOOP
        target_path = public.mt_jsonb_path_to_array(target, '\.');
        retval = public.mt_jsonb_copy(retval, location, target_path);
    END LOOP;

    RETURN retval;
END;
$$;

alter function mt_jsonb_duplicate(jsonb, text[], jsonb) owner to postgres;

