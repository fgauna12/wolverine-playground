create function mt_immutable_date(value text) returns date
    immutable
    language sql
as
$$
select value::date

$$;

alter function mt_immutable_date(text) owner to postgres;

