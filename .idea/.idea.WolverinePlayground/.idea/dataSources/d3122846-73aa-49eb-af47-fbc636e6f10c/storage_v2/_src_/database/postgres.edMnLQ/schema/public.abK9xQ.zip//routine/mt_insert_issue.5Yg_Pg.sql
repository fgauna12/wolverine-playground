create function mt_insert_issue(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) returns uuid
    language plpgsql
as
$$
BEGIN
INSERT INTO public.mt_doc_issue ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp());

  RETURN docVersion;
END;
$$;

alter function mt_insert_issue(jsonb, varchar, uuid, uuid) owner to postgres;

