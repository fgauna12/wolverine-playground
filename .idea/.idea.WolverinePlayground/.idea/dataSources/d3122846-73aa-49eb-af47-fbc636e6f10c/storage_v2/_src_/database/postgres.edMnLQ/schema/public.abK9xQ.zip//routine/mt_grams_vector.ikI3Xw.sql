create function mt_grams_vector(text) returns tsvector
    immutable
    strict
    language plpgsql
as
$$
BEGIN
RETURN (SELECT array_to_string(public.mt_grams_array($1), ' ') ::tsvector);
END
$$;

alter function mt_grams_vector(text) owner to postgres;

