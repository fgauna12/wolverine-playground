create function mt_jsonb_path_to_array(text, character) returns text[]
    language plpgsql
as
$$
DECLARE
    location ALIAS FOR $1;
    regex_pattern ALIAS FOR $2;
BEGIN
RETURN regexp_split_to_array(location, regex_pattern)::text[];
END;
$$;

alter function mt_jsonb_path_to_array(text, char) owner to postgres;

